function setup() {
  createCanvas(400, 400);
  fill('darkblue');

}

function draw() {
  background(220);
  circle(75,75,100);
  circle(325,75,100);
  circle(75,325,100);
  circle(325,75,100);
  circle(325,325,100)
  square(75,75,100);
}


